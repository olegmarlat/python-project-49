#!/usr/bin/env python3
from brain_games.games.even import even_game_one


def main():
    even_game_one()


if __name__ == '__main__':
    main()
