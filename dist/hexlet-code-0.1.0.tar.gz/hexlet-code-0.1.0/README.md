l# python-project-49
<a href="https://codeclimate.com/github/olegmarlat/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ea185df7bfad311f1ff2/maintainability" /></a>
